import{a as Be}from"./chunk-PDZPGKYU.js";import{a as Ve}from"./chunk-K66J7UOM.js";import{b as Le,c as Oe}from"./chunk-W2VCTNMP.js";import{b as De,c as Ne}from"./chunk-5DZL6542.js";import{a as Fe}from"./chunk-EWVAKTRI.js";import{a as Me,b as ze}from"./chunk-WN6474NT.js";import{b as we}from"./chunk-IPYKI4XL.js";import"./chunk-IDUNRVSA.js";import{a as Pe,c as Se,f as Te}from"./chunk-6SHTQL25.js";import{a as qe}from"./chunk-UG2CW4XV.js";import{c as Re}from"./chunk-TMDFQ4M4.js";import"./chunk-AHK2GEUY.js";import{a as Ee,b as Ie}from"./chunk-GFTC5H2I.js";import{a as pe,b as _e}from"./chunk-RUZXLKWG.js";import{a as ge,b as ye,c as Ce}from"./chunk-64U6TBGS.js";import{A as fe,C as ve,p as ue}from"./chunk-3HWJT3GB.js";import{a as be,f as ke,m as xe}from"./chunk-QHNVJ25K.js";import{a as je}from"./chunk-5FJ535AM.js";import{a as ae,b as re,c as de,f as le,i as F,m as me,u as se,v as he}from"./chunk-U2K6P2VD.js";import{a as Ae}from"./chunk-P6EOUDUM.js";import{c as ie}from"./chunk-L2LTXI6X.js";import"./chunk-WXOJILIG.js";import{$ as s,$a as x,Cb as W,Da as r,Eb as y,Fb as Y,Gb as d,Hb as z,Ib as f,Jb as C,Oa as E,Ob as ee,Pa as Q,V as L,X as O,Z as V,Za as T,_a as u,_b as te,cb as I,da as v,db as j,ea as g,eb as h,ec as ne,fa as B,fb as i,ga as q,gb as a,gc as _,hb as k,hc as ce,la as S,ma as $,ob as A,pa as U,pb as H,qb as b,ra as G,sb as p,tb as Z,tc as oe,ua as X,ub as K,wb as J,xb as w,yb as M}from"./chunk-WP2XCR7D.js";var Qe=["input"],He=["label"],Ze=["*"],D={color:"accent",clickAction:"check-indeterminate",disabledInteractive:!1},Ke=new V("mat-checkbox-default-options",{providedIn:"root",factory:()=>D}),m=(function(t){return t[t.Init=0]="Init",t[t.Checked=1]="Checked",t[t.Unchecked=2]="Unchecked",t[t.Indeterminate=3]="Indeterminate",t})(m||{}),N=class{source;checked},R=(()=>{class t{_elementRef=s(X);_changeDetectorRef=s(ne);_ngZone=s($);_animationsDisabled=xe();_options=s(Ke,{optional:!0});focus(){this._inputElement.nativeElement.focus()}_createChangeEvent(e){let c=new N;return c.source=this,c.checked=e,c}_getAnimationTargetElement(){return this._inputElement?.nativeElement}_animationClasses={uncheckedToChecked:"mdc-checkbox--anim-unchecked-checked",uncheckedToIndeterminate:"mdc-checkbox--anim-unchecked-indeterminate",checkedToUnchecked:"mdc-checkbox--anim-checked-unchecked",checkedToIndeterminate:"mdc-checkbox--anim-checked-indeterminate",indeterminateToChecked:"mdc-checkbox--anim-indeterminate-checked",indeterminateToUnchecked:"mdc-checkbox--anim-indeterminate-unchecked"};ariaLabel="";ariaLabelledby=null;ariaDescribedby;ariaExpanded;ariaControls;ariaOwns;_uniqueId;id;get inputId(){return`${this.id||this._uniqueId}-input`}required=!1;labelPosition="after";name=null;change=new S;indeterminateChange=new S;value;disableRipple=!1;_inputElement;_labelElement;tabIndex;color;disabledInteractive;_onTouched=()=>{};_currentAnimationClass="";_currentCheckState=m.Init;_controlValueAccessorChangeFn=()=>{};_validatorChangeFn=()=>{};constructor(){s(be).load(ve);let e=s(new te("tabindex"),{optional:!0});this._options=this._options||D,this.color=this._options.color||D.color,this.tabIndex=e==null?0:parseInt(e)||0,this.id=this._uniqueId=s(ue).getId("mat-mdc-checkbox-"),this.disabledInteractive=this._options?.disabledInteractive??!1}ngOnChanges(e){e.required&&this._validatorChangeFn()}ngAfterViewInit(){this._syncIndeterminate(this.indeterminate)}get checked(){return this._checked}set checked(e){e!=this.checked&&(this._checked=e,this._changeDetectorRef.markForCheck())}_checked=!1;get disabled(){return this._disabled}set disabled(e){e!==this.disabled&&(this._disabled=e,this._changeDetectorRef.markForCheck())}_disabled=!1;get indeterminate(){return this._indeterminate()}set indeterminate(e){let c=e!=this._indeterminate();this._indeterminate.set(e),c&&(e?this._transitionCheckState(m.Indeterminate):this._transitionCheckState(this.checked?m.Checked:m.Unchecked),this.indeterminateChange.emit(e)),this._syncIndeterminate(e)}_indeterminate=U(!1);_isRippleDisabled(){return this.disableRipple||this.disabled}_onLabelTextChange(){this._changeDetectorRef.detectChanges()}writeValue(e){this.checked=!!e}registerOnChange(e){this._controlValueAccessorChangeFn=e}registerOnTouched(e){this._onTouched=e}setDisabledState(e){this.disabled=e}validate(e){return this.required&&e.value!==!0?{required:!0}:null}registerOnValidatorChange(e){this._validatorChangeFn=e}_transitionCheckState(e){let c=this._currentCheckState,n=this._getAnimationTargetElement();if(!(c===e||!n)&&(this._currentAnimationClass&&n.classList.remove(this._currentAnimationClass),this._currentAnimationClass=this._getAnimationClassForCheckStateTransition(c,e),this._currentCheckState=e,this._currentAnimationClass.length>0)){n.classList.add(this._currentAnimationClass);let l=this._currentAnimationClass;this._ngZone.runOutsideAngular(()=>{setTimeout(()=>{n.classList.remove(l)},1e3)})}}_emitChangeEvent(){this._controlValueAccessorChangeFn(this.checked),this.change.emit(this._createChangeEvent(this.checked)),this._inputElement&&(this._inputElement.nativeElement.checked=this.checked)}toggle(){this.checked=!this.checked,this._controlValueAccessorChangeFn(this.checked)}_handleInputClick(){let e=this._options?.clickAction;!this.disabled&&e!=="noop"?(this.indeterminate&&e!=="check"&&Promise.resolve().then(()=>{this._indeterminate.set(!1),this.indeterminateChange.emit(!1)}),this._checked=!this._checked,this._transitionCheckState(this._checked?m.Checked:m.Unchecked),this._emitChangeEvent()):(this.disabled&&this.disabledInteractive||!this.disabled&&e==="noop")&&(this._inputElement.nativeElement.checked=this.checked,this._inputElement.nativeElement.indeterminate=this.indeterminate)}_onInteractionEvent(e){e.stopPropagation()}_onBlur(){Promise.resolve().then(()=>{this._onTouched(),this._changeDetectorRef.markForCheck()})}_getAnimationClassForCheckStateTransition(e,c){if(this._animationsDisabled)return"";switch(e){case m.Init:if(c===m.Checked)return this._animationClasses.uncheckedToChecked;if(c==m.Indeterminate)return this._checked?this._animationClasses.checkedToIndeterminate:this._animationClasses.uncheckedToIndeterminate;break;case m.Unchecked:return c===m.Checked?this._animationClasses.uncheckedToChecked:this._animationClasses.uncheckedToIndeterminate;case m.Checked:return c===m.Unchecked?this._animationClasses.checkedToUnchecked:this._animationClasses.checkedToIndeterminate;case m.Indeterminate:return c===m.Checked?this._animationClasses.indeterminateToChecked:this._animationClasses.indeterminateToUnchecked}return""}_syncIndeterminate(e){let c=this._inputElement;c&&(c.nativeElement.indeterminate=e)}_onInputClick(){this._handleInputClick()}_onTouchTargetClick(){this._handleInputClick(),this.disabled||this._inputElement.nativeElement.focus()}_preventBubblingFromLabel(e){e.target&&this._labelElement.nativeElement.contains(e.target)&&e.stopPropagation()}static \u0275fac=function(c){return new(c||t)};static \u0275cmp=E({type:t,selectors:[["mat-checkbox"]],viewQuery:function(c,n){if(c&1&&J(Qe,5)(He,5),c&2){let l;w(l=M())&&(n._inputElement=l.first),w(l=M())&&(n._labelElement=l.first)}},hostAttrs:[1,"mat-mdc-checkbox"],hostVars:16,hostBindings:function(c,n){c&2&&(H("id",n.id),T("tabindex",null)("aria-label",null)("aria-labelledby",null),Y(n.color?"mat-"+n.color:"mat-accent"),y("_mat-animation-noopable",n._animationsDisabled)("mdc-checkbox--disabled",n.disabled)("mat-mdc-checkbox-disabled",n.disabled)("mat-mdc-checkbox-checked",n.checked)("mat-mdc-checkbox-disabled-interactive",n.disabledInteractive))},inputs:{ariaLabel:[0,"aria-label","ariaLabel"],ariaLabelledby:[0,"aria-labelledby","ariaLabelledby"],ariaDescribedby:[0,"aria-describedby","ariaDescribedby"],ariaExpanded:[2,"aria-expanded","ariaExpanded",_],ariaControls:[0,"aria-controls","ariaControls"],ariaOwns:[0,"aria-owns","ariaOwns"],id:"id",required:[2,"required","required",_],labelPosition:"labelPosition",name:"name",value:"value",disableRipple:[2,"disableRipple","disableRipple",_],tabIndex:[2,"tabIndex","tabIndex",e=>e==null?void 0:ce(e)],color:"color",disabledInteractive:[2,"disabledInteractive","disabledInteractive",_],checked:[2,"checked","checked",_],disabled:[2,"disabled","disabled",_],indeterminate:[2,"indeterminate","indeterminate",_]},outputs:{change:"change",indeterminateChange:"indeterminateChange"},exportAs:["matCheckbox"],features:[ee([{provide:ae,useExisting:L(()=>t),multi:!0},{provide:de,useExisting:t,multi:!0}]),G],ngContentSelectors:Ze,decls:15,vars:23,consts:[["checkbox",""],["input",""],["label",""],["mat-internal-form-field","",3,"click","labelPosition"],[1,"mdc-checkbox"],["aria-hidden","true",1,"mat-mdc-checkbox-touch-target",3,"click"],["type","checkbox",1,"mdc-checkbox__native-control",3,"blur","click","change","checked","indeterminate","disabled","id","required","tabIndex"],["aria-hidden","true",1,"mdc-checkbox__ripple"],["aria-hidden","true",1,"mdc-checkbox__background"],["focusable","false","viewBox","0 0 24 24",1,"mdc-checkbox__checkmark"],["fill","none","d","M1.73,12.91 8.1,19.28 22.79,4.59",1,"mdc-checkbox__checkmark-path"],[1,"mdc-checkbox__mixedmark"],["mat-ripple","","aria-hidden","true",1,"mat-mdc-checkbox-ripple","mat-focus-indicator",3,"matRippleTrigger","matRippleDisabled","matRippleCentered"],[1,"mdc-label",3,"for"]],template:function(c,n){if(c&1&&(Z(),i(0,"div",3),b("click",function(P){return n._preventBubblingFromLabel(P)}),i(1,"div",4,0)(3,"div",5),b("click",function(){return n._onTouchTargetClick()}),a(),i(4,"input",6,1),b("blur",function(){return n._onBlur()})("click",function(){return n._onInputClick()})("change",function(P){return n._onInteractionEvent(P)}),a(),k(6,"div",7),i(7,"div",8),B(),i(8,"svg",9),k(9,"path",10),a(),q(),k(10,"div",11),a(),k(11,"div",12),a(),i(12,"label",13,2),K(14),a()()),c&2){let l=W(2);h("labelPosition",n.labelPosition),r(4),y("mdc-checkbox--selected",n.checked),h("checked",n.checked)("indeterminate",n.indeterminate)("disabled",n.disabled&&!n.disabledInteractive)("id",n.inputId)("required",n.required)("tabIndex",n.disabled&&!n.disabledInteractive?-1:n.tabIndex),T("aria-label",n.ariaLabel||null)("aria-labelledby",n.ariaLabelledby)("aria-describedby",n.ariaDescribedby)("aria-checked",n.indeterminate?"mixed":null)("aria-controls",n.ariaControls)("aria-disabled",n.disabled&&n.disabledInteractive?!0:null)("aria-expanded",n.ariaExpanded)("aria-owns",n.ariaOwns)("name",n.name)("value",n.value),r(7),h("matRippleTrigger",l)("matRippleDisabled",n.disableRipple||n.disabled)("matRippleCentered",!0),r(),h("for",n.inputId)}},dependencies:[fe,qe],styles:[`.mdc-checkbox {
  display: inline-block;
  position: relative;
  flex: 0 0 18px;
  box-sizing: content-box;
  width: 18px;
  height: 18px;
  line-height: 0;
  white-space: nowrap;
  cursor: pointer;
  vertical-align: bottom;
  padding: calc((var(--mat-checkbox-state-layer-size, 40px) - 18px) / 2);
  margin: calc((var(--mat-checkbox-state-layer-size, 40px) - var(--mat-checkbox-state-layer-size, 40px)) / 2);
}
.mdc-checkbox:hover > .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-unselected-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
  background-color: var(--mat-checkbox-unselected-hover-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox:hover > .mat-mdc-checkbox-ripple > .mat-ripple-element {
  background-color: var(--mat-checkbox-unselected-hover-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox .mdc-checkbox__native-control:focus + .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-unselected-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
  background-color: var(--mat-checkbox-unselected-focus-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox .mdc-checkbox__native-control:focus ~ .mat-mdc-checkbox-ripple .mat-ripple-element {
  background-color: var(--mat-checkbox-unselected-focus-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox:active > .mdc-checkbox__native-control + .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-unselected-pressed-state-layer-opacity, var(--mat-sys-pressed-state-layer-opacity));
  background-color: var(--mat-checkbox-unselected-pressed-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox:active > .mdc-checkbox__native-control ~ .mat-mdc-checkbox-ripple .mat-ripple-element {
  background-color: var(--mat-checkbox-unselected-pressed-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox:hover > .mdc-checkbox__native-control:checked + .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-selected-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
  background-color: var(--mat-checkbox-selected-hover-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox:hover > .mdc-checkbox__native-control:checked ~ .mat-mdc-checkbox-ripple .mat-ripple-element {
  background-color: var(--mat-checkbox-selected-hover-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox .mdc-checkbox__native-control:focus:checked + .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-selected-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
  background-color: var(--mat-checkbox-selected-focus-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox .mdc-checkbox__native-control:focus:checked ~ .mat-mdc-checkbox-ripple .mat-ripple-element {
  background-color: var(--mat-checkbox-selected-focus-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox:active > .mdc-checkbox__native-control:checked + .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-selected-pressed-state-layer-opacity, var(--mat-sys-pressed-state-layer-opacity));
  background-color: var(--mat-checkbox-selected-pressed-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox:active > .mdc-checkbox__native-control:checked ~ .mat-mdc-checkbox-ripple .mat-ripple-element {
  background-color: var(--mat-checkbox-selected-pressed-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox .mdc-checkbox__native-control ~ .mat-mdc-checkbox-ripple .mat-ripple-element,
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox .mdc-checkbox__native-control + .mdc-checkbox__ripple {
  background-color: var(--mat-checkbox-unselected-hover-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox .mdc-checkbox__native-control {
  position: absolute;
  margin: 0;
  padding: 0;
  opacity: 0;
  cursor: inherit;
  z-index: 1;
  width: var(--mat-checkbox-state-layer-size, 40px);
  height: var(--mat-checkbox-state-layer-size, 40px);
  top: calc((var(--mat-checkbox-state-layer-size, 40px) - var(--mat-checkbox-state-layer-size, 40px)) / 2);
  right: calc((var(--mat-checkbox-state-layer-size, 40px) - var(--mat-checkbox-state-layer-size, 40px)) / 2);
  left: calc((var(--mat-checkbox-state-layer-size, 40px) - var(--mat-checkbox-state-layer-size, 40px)) / 2);
}

.mdc-checkbox--disabled {
  cursor: default;
  pointer-events: none;
}

.mdc-checkbox__background {
  display: inline-flex;
  position: absolute;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  width: 18px;
  height: 18px;
  border: 2px solid currentColor;
  border-radius: 2px;
  background-color: transparent;
  pointer-events: none;
  will-change: background-color, border-color;
  transition: background-color 90ms cubic-bezier(0.4, 0, 0.6, 1), border-color 90ms cubic-bezier(0.4, 0, 0.6, 1);
  -webkit-print-color-adjust: exact;
  color-adjust: exact;
  border-color: var(--mat-checkbox-unselected-icon-color, var(--mat-sys-on-surface-variant));
  top: calc((var(--mat-checkbox-state-layer-size, 40px) - 18px) / 2);
  left: calc((var(--mat-checkbox-state-layer-size, 40px) - 18px) / 2);
}

.mdc-checkbox__native-control:enabled:checked ~ .mdc-checkbox__background,
.mdc-checkbox__native-control:enabled:indeterminate ~ .mdc-checkbox__background {
  border-color: var(--mat-checkbox-selected-icon-color, var(--mat-sys-primary));
  background-color: var(--mat-checkbox-selected-icon-color, var(--mat-sys-primary));
}

.mdc-checkbox--disabled .mdc-checkbox__background {
  border-color: var(--mat-checkbox-disabled-unselected-icon-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
@media (forced-colors: active) {
  .mdc-checkbox--disabled .mdc-checkbox__background {
    border-color: GrayText;
  }
}

.mdc-checkbox__native-control:disabled:checked ~ .mdc-checkbox__background,
.mdc-checkbox__native-control:disabled:indeterminate ~ .mdc-checkbox__background {
  background-color: var(--mat-checkbox-disabled-selected-icon-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
  border-color: transparent;
}
@media (forced-colors: active) {
  .mdc-checkbox__native-control:disabled:checked ~ .mdc-checkbox__background,
  .mdc-checkbox__native-control:disabled:indeterminate ~ .mdc-checkbox__background {
    border-color: GrayText;
  }
}

.mdc-checkbox:hover > .mdc-checkbox__native-control:not(:checked) ~ .mdc-checkbox__background,
.mdc-checkbox:hover > .mdc-checkbox__native-control:not(:indeterminate) ~ .mdc-checkbox__background {
  border-color: var(--mat-checkbox-unselected-hover-icon-color, var(--mat-sys-on-surface));
  background-color: transparent;
}

.mdc-checkbox:hover > .mdc-checkbox__native-control:checked ~ .mdc-checkbox__background,
.mdc-checkbox:hover > .mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background {
  border-color: var(--mat-checkbox-selected-hover-icon-color, var(--mat-sys-primary));
  background-color: var(--mat-checkbox-selected-hover-icon-color, var(--mat-sys-primary));
}

.mdc-checkbox__native-control:focus:focus:not(:checked) ~ .mdc-checkbox__background,
.mdc-checkbox__native-control:focus:focus:not(:indeterminate) ~ .mdc-checkbox__background {
  border-color: var(--mat-checkbox-unselected-focus-icon-color, var(--mat-sys-on-surface));
}

.mdc-checkbox__native-control:focus:focus:checked ~ .mdc-checkbox__background,
.mdc-checkbox__native-control:focus:focus:indeterminate ~ .mdc-checkbox__background {
  border-color: var(--mat-checkbox-selected-focus-icon-color, var(--mat-sys-primary));
  background-color: var(--mat-checkbox-selected-focus-icon-color, var(--mat-sys-primary));
}

.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox:hover > .mdc-checkbox__native-control ~ .mdc-checkbox__background,
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox .mdc-checkbox__native-control:focus ~ .mdc-checkbox__background,
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__background {
  border-color: var(--mat-checkbox-disabled-unselected-icon-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
@media (forced-colors: active) {
  .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox:hover > .mdc-checkbox__native-control ~ .mdc-checkbox__background,
  .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox .mdc-checkbox__native-control:focus ~ .mdc-checkbox__background,
  .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__background {
    border-color: GrayText;
  }
}
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__native-control:checked ~ .mdc-checkbox__background,
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background {
  background-color: var(--mat-checkbox-disabled-selected-icon-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
  border-color: transparent;
}

.mdc-checkbox__checkmark {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  width: 100%;
  opacity: 0;
  transition: opacity 180ms cubic-bezier(0.4, 0, 0.6, 1);
  color: var(--mat-checkbox-selected-checkmark-color, var(--mat-sys-on-primary));
}
@media (forced-colors: active) {
  .mdc-checkbox__checkmark {
    color: CanvasText;
  }
}

.mdc-checkbox--disabled .mdc-checkbox__checkmark, .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__checkmark {
  color: var(--mat-checkbox-disabled-selected-checkmark-color, var(--mat-sys-surface));
}
@media (forced-colors: active) {
  .mdc-checkbox--disabled .mdc-checkbox__checkmark, .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__checkmark {
    color: GrayText;
  }
}

.mdc-checkbox__checkmark-path {
  transition: stroke-dashoffset 180ms cubic-bezier(0.4, 0, 0.6, 1);
  stroke: currentColor;
  stroke-width: 3.12px;
  stroke-dashoffset: 29.7833385;
  stroke-dasharray: 29.7833385;
}

.mdc-checkbox__mixedmark {
  width: 100%;
  height: 0;
  transform: scaleX(0) rotate(0deg);
  border-width: 1px;
  border-style: solid;
  opacity: 0;
  transition: opacity 90ms cubic-bezier(0.4, 0, 0.6, 1), transform 90ms cubic-bezier(0.4, 0, 0.6, 1);
  border-color: var(--mat-checkbox-selected-checkmark-color, var(--mat-sys-on-primary));
}
@media (forced-colors: active) {
  .mdc-checkbox__mixedmark {
    margin: 0 1px;
  }
}

.mdc-checkbox--disabled .mdc-checkbox__mixedmark, .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__mixedmark {
  border-color: var(--mat-checkbox-disabled-selected-checkmark-color, var(--mat-sys-surface));
}
@media (forced-colors: active) {
  .mdc-checkbox--disabled .mdc-checkbox__mixedmark, .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__mixedmark {
    border-color: GrayText;
  }
}

.mdc-checkbox--anim-unchecked-checked .mdc-checkbox__background,
.mdc-checkbox--anim-unchecked-indeterminate .mdc-checkbox__background,
.mdc-checkbox--anim-checked-unchecked .mdc-checkbox__background,
.mdc-checkbox--anim-indeterminate-unchecked .mdc-checkbox__background {
  animation-duration: 180ms;
  animation-timing-function: linear;
}

.mdc-checkbox--anim-unchecked-checked .mdc-checkbox__checkmark-path {
  animation: mdc-checkbox-unchecked-checked-checkmark-path 180ms linear;
  transition: none;
}

.mdc-checkbox--anim-unchecked-indeterminate .mdc-checkbox__mixedmark {
  animation: mdc-checkbox-unchecked-indeterminate-mixedmark 90ms linear;
  transition: none;
}

.mdc-checkbox--anim-checked-unchecked .mdc-checkbox__checkmark-path {
  animation: mdc-checkbox-checked-unchecked-checkmark-path 90ms linear;
  transition: none;
}

.mdc-checkbox--anim-checked-indeterminate .mdc-checkbox__checkmark {
  animation: mdc-checkbox-checked-indeterminate-checkmark 90ms linear;
  transition: none;
}
.mdc-checkbox--anim-checked-indeterminate .mdc-checkbox__mixedmark {
  animation: mdc-checkbox-checked-indeterminate-mixedmark 90ms linear;
  transition: none;
}

.mdc-checkbox--anim-indeterminate-checked .mdc-checkbox__checkmark {
  animation: mdc-checkbox-indeterminate-checked-checkmark 500ms linear;
  transition: none;
}
.mdc-checkbox--anim-indeterminate-checked .mdc-checkbox__mixedmark {
  animation: mdc-checkbox-indeterminate-checked-mixedmark 500ms linear;
  transition: none;
}

.mdc-checkbox--anim-indeterminate-unchecked .mdc-checkbox__mixedmark {
  animation: mdc-checkbox-indeterminate-unchecked-mixedmark 300ms linear;
  transition: none;
}

.mdc-checkbox__native-control:checked ~ .mdc-checkbox__background,
.mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background {
  transition: border-color 90ms cubic-bezier(0, 0, 0.2, 1), background-color 90ms cubic-bezier(0, 0, 0.2, 1);
}
.mdc-checkbox__native-control:checked ~ .mdc-checkbox__background > .mdc-checkbox__checkmark > .mdc-checkbox__checkmark-path,
.mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background > .mdc-checkbox__checkmark > .mdc-checkbox__checkmark-path {
  stroke-dashoffset: 0;
}

.mdc-checkbox__native-control:checked ~ .mdc-checkbox__background > .mdc-checkbox__checkmark {
  transition: opacity 180ms cubic-bezier(0, 0, 0.2, 1), transform 180ms cubic-bezier(0, 0, 0.2, 1);
  opacity: 1;
}
.mdc-checkbox__native-control:checked ~ .mdc-checkbox__background > .mdc-checkbox__mixedmark {
  transform: scaleX(1) rotate(-45deg);
}

.mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background > .mdc-checkbox__checkmark {
  transform: rotate(45deg);
  opacity: 0;
  transition: opacity 90ms cubic-bezier(0.4, 0, 0.6, 1), transform 90ms cubic-bezier(0.4, 0, 0.6, 1);
}
.mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background > .mdc-checkbox__mixedmark {
  transform: scaleX(1) rotate(0deg);
  opacity: 1;
}

@keyframes mdc-checkbox-unchecked-checked-checkmark-path {
  0%, 50% {
    stroke-dashoffset: 29.7833385;
  }
  50% {
    animation-timing-function: cubic-bezier(0, 0, 0.2, 1);
  }
  100% {
    stroke-dashoffset: 0;
  }
}
@keyframes mdc-checkbox-unchecked-indeterminate-mixedmark {
  0%, 68.2% {
    transform: scaleX(0);
  }
  68.2% {
    animation-timing-function: cubic-bezier(0, 0, 0, 1);
  }
  100% {
    transform: scaleX(1);
  }
}
@keyframes mdc-checkbox-checked-unchecked-checkmark-path {
  from {
    animation-timing-function: cubic-bezier(0.4, 0, 1, 1);
    opacity: 1;
    stroke-dashoffset: 0;
  }
  to {
    opacity: 0;
    stroke-dashoffset: -29.7833385;
  }
}
@keyframes mdc-checkbox-checked-indeterminate-checkmark {
  from {
    animation-timing-function: cubic-bezier(0, 0, 0.2, 1);
    transform: rotate(0deg);
    opacity: 1;
  }
  to {
    transform: rotate(45deg);
    opacity: 0;
  }
}
@keyframes mdc-checkbox-indeterminate-checked-checkmark {
  from {
    animation-timing-function: cubic-bezier(0.14, 0, 0, 1);
    transform: rotate(45deg);
    opacity: 0;
  }
  to {
    transform: rotate(360deg);
    opacity: 1;
  }
}
@keyframes mdc-checkbox-checked-indeterminate-mixedmark {
  from {
    animation-timing-function: cubic-bezier(0, 0, 0.2, 1);
    transform: rotate(-45deg);
    opacity: 0;
  }
  to {
    transform: rotate(0deg);
    opacity: 1;
  }
}
@keyframes mdc-checkbox-indeterminate-checked-mixedmark {
  from {
    animation-timing-function: cubic-bezier(0.14, 0, 0, 1);
    transform: rotate(0deg);
    opacity: 1;
  }
  to {
    transform: rotate(315deg);
    opacity: 0;
  }
}
@keyframes mdc-checkbox-indeterminate-unchecked-mixedmark {
  0% {
    animation-timing-function: linear;
    transform: scaleX(1);
    opacity: 1;
  }
  32.8%, 100% {
    transform: scaleX(0);
    opacity: 0;
  }
}
.mat-mdc-checkbox {
  display: inline-block;
  position: relative;
  -webkit-tap-highlight-color: transparent;
}
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mat-mdc-checkbox-touch-target,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__native-control,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__ripple,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mat-mdc-checkbox-ripple::before,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__background,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__background > .mdc-checkbox__checkmark,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__background > .mdc-checkbox__checkmark > .mdc-checkbox__checkmark-path,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__background > .mdc-checkbox__mixedmark {
  transition: none !important;
  animation: none !important;
}
.mat-mdc-checkbox label {
  cursor: pointer;
}
.mat-mdc-checkbox .mat-internal-form-field {
  color: var(--mat-checkbox-label-text-color, var(--mat-sys-on-surface));
  font-family: var(--mat-checkbox-label-text-font, var(--mat-sys-body-medium-font));
  line-height: var(--mat-checkbox-label-text-line-height, var(--mat-sys-body-medium-line-height));
  font-size: var(--mat-checkbox-label-text-size, var(--mat-sys-body-medium-size));
  letter-spacing: var(--mat-checkbox-label-text-tracking, var(--mat-sys-body-medium-tracking));
  font-weight: var(--mat-checkbox-label-text-weight, var(--mat-sys-body-medium-weight));
}
.mat-mdc-checkbox.mat-mdc-checkbox-disabled.mat-mdc-checkbox-disabled-interactive {
  pointer-events: auto;
}
.mat-mdc-checkbox.mat-mdc-checkbox-disabled.mat-mdc-checkbox-disabled-interactive input {
  cursor: default;
}
.mat-mdc-checkbox.mat-mdc-checkbox-disabled label {
  cursor: default;
  color: var(--mat-checkbox-disabled-label-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
@media (forced-colors: active) {
  .mat-mdc-checkbox.mat-mdc-checkbox-disabled label {
    color: GrayText;
  }
}
.mat-mdc-checkbox label:empty {
  display: none;
}
.mat-mdc-checkbox .mdc-checkbox__ripple {
  opacity: 0;
}

.mat-mdc-checkbox .mat-mdc-checkbox-ripple,
.mdc-checkbox__ripple {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  border-radius: 50%;
  pointer-events: none;
}
.mat-mdc-checkbox .mat-mdc-checkbox-ripple:not(:empty),
.mdc-checkbox__ripple:not(:empty) {
  transform: translateZ(0);
}

.mat-mdc-checkbox-ripple .mat-ripple-element {
  opacity: 0.1;
}

.mat-mdc-checkbox-touch-target {
  position: absolute;
  top: 50%;
  left: 50%;
  height: var(--mat-checkbox-touch-target-size, 48px);
  width: var(--mat-checkbox-touch-target-size, 48px);
  transform: translate(-50%, -50%);
  display: var(--mat-checkbox-touch-target-display, block);
}

.mat-mdc-checkbox .mat-mdc-checkbox-ripple::before {
  border-radius: 50%;
}

.mdc-checkbox__native-control:focus-visible ~ .mat-focus-indicator::before {
  content: "";
}
`],encapsulation:2,changeDetection:0})}return t})(),$e=(()=>{class t{static \u0275fac=function(c){return new(c||t)};static \u0275mod=Q({type:t});static \u0275inj=O({imports:[R,ke]})}return t})();var We=(t,o)=>o.projectId,Ge=(t,o)=>o.employeeId;function Ye(t,o){if(t&1&&(i(0,"mat-option",8),d(1),i(2,"span",11),d(3),a()()),t&2){let e=o.$implicit;h("value",e),r(),f(" ",e.projectName," "),r(2),f("- ",e.clientName||"No client")}}function et(t,o){t&1&&(i(0,"div",9)(1,"mat-icon",12),d(2,"group_add"),a(),i(3,"p",13),d(4,"Select a project to manage allocations"),a(),i(5,"p",14),d(6,"Assign employees or remove existing allocations"),a()())}function tt(t,o){t&1&&(i(0,"div",19),k(1,"mat-spinner",22),a())}function nt(t,o){t&1&&(i(0,"div",20)(1,"mat-icon",23),d(2,"person_off"),a(),i(3,"p",24),d(4,"No employees assigned"),a()())}function ct(t,o){if(t&1){let e=A();i(0,"div",25)(1,"div",26),d(2),a(),i(3,"div",27)(4,"span",28),d(5),a(),i(6,"span",29),d(7),a()(),i(8,"button",30),b("click",function(){let n=v(e).$implicit,l=p(3);return g(l.removeAllocation(n))}),i(9,"mat-icon"),d(10,"remove_circle"),a()()()}if(t&2){let e=o.$implicit;r(2),C("",e.firstName[0],"",e.lastName[0]),r(3),C("",e.firstName," ",e.lastName),r(2),z(e.departmentName)}}function ot(t,o){if(t&1&&(i(0,"div",21),I(1,ct,11,5,"div",25,Ge),a()),t&2){let e=p(2);r(),j(e.assignedEmployees)}}function it(t,o){t&1&&(i(0,"div",19),k(1,"mat-spinner",22),a())}function at(t,o){t&1&&(i(0,"div",20)(1,"mat-icon",23),d(2,"group"),a(),i(3,"p",24),d(4,"All employees are assigned to this project"),a()())}function rt(t,o){if(t&1){let e=A();i(0,"div",37),b("click",function(){let n=v(e).$implicit,l=p(3);return g(l.toggleSelect(n))}),i(1,"div",26),d(2),a(),i(3,"div",27)(4,"span",28),d(5),a(),i(6,"span",29),d(7),a()(),i(8,"mat-checkbox",38),b("click",function(n){return n.stopPropagation()})("change",function(){let n=v(e).$implicit,l=p(3);return g(l.toggleSelect(n))}),a()()}if(t&2){let e=o.$implicit,c=p(3);y("selected",c.isSelected(e)),r(2),C("",e.firstName[0],"",e.lastName[0]),r(3),C("",e.firstName," ",e.lastName),r(2),z(e.departmentName),r(),h("checked",c.isSelected(e))}}function dt(t,o){t&1&&k(0,"mat-spinner",40)}function lt(t,o){if(t&1){let e=A();i(0,"div",36)(1,"button",39),b("click",function(){v(e);let n=p(3);return g(n.assignSelected())}),u(2,dt,1,0,"mat-spinner",40),d(3),a()()}if(t&2){let e=p(3);r(),h("disabled",e.assigning),r(),x(e.assigning?2:-1),r(),f(" Assign Selected (",e.selectedEmployees.length,") ")}}function mt(t,o){if(t&1&&(i(0,"div",31)(1,"mat-form-field",6)(2,"mat-label"),d(3,"Search employees"),a(),k(4,"input",32),i(5,"mat-icon",33),d(6,"search"),a()()(),i(7,"div",34),I(8,rt,9,8,"div",35,Ge),a(),u(10,lt,4,3,"div",36)),t&2){let e=p(2);r(4),h("formControl",e.searchControl),r(4),j(e.filteredAvailableEmployees),r(2),x(e.selectedEmployees.length>0?10:-1)}}function st(t,o){if(t&1&&(i(0,"div",10)(1,"div",15)(2,"div",16)(3,"div")(4,"h2",17),d(5,"Assigned Employees"),a(),i(6,"p",18),d(7),a()()(),u(8,tt,2,0,"div",19)(9,nt,5,0,"div",20)(10,ot,3,0,"div",21),a(),i(11,"div",15)(12,"div",16)(13,"div")(14,"h2",17),d(15,"Available Employees"),a(),i(16,"p",18),d(17),a()()(),u(18,it,2,0,"div",19)(19,at,5,0,"div",20)(20,mt,11,2),a()()),t&2){let e=p();r(7),f("",e.assignedEmployees.length," currently assigned"),r(),x(e.loadingAllocations?8:e.assignedEmployees.length===0?9:10),r(9),f("",e.availableEmployees.length," unassigned"),r(),x(e.loadingEmployees?18:e.availableEmployees.length===0?19:20)}}var Ue=class t{projects=[];allEmployees=[];selectedProject=null;assignedEmployees=[];availableEmployees=[];selectedEmployees=[];filteredAvailableEmployees=[];allocations=[];loadingAllocations=!1;loadingEmployees=!1;assigning=!1;projectControl=new F(null);searchControl=new F("");projectService=s(Ae);employeeService=s(je);snackBar=s(Me);router=s(ie);ngOnInit(){this.loadProjects(),this.loadEmployees(),this.searchControl.valueChanges.subscribe(o=>{let e=(o||"").toLowerCase();this.filteredAvailableEmployees=this.availableEmployees.filter(c=>c.firstName.toLowerCase().includes(e)||c.lastName.toLowerCase().includes(e)||(c.departmentName||"").toLowerCase().includes(e))})}loadProjects(){this.projectService.getAll().subscribe(o=>{this.projects=o})}loadEmployees(){this.loadingEmployees=!0,this.employeeService.getAll().subscribe({next:o=>{this.allEmployees=o.filter(e=>e.status==="Active"),this.loadingEmployees=!1,this.selectedProject&&this.updateEmployeeLists()},error:()=>{this.loadingEmployees=!1}})}onProjectChange(o){if(this.selectedProject=o,this.selectedEmployees=[],!o){this.assignedEmployees=[],this.availableEmployees=[];return}this.loadAllocationsForProject(o.projectId)}loadAllocationsForProject(o){this.loadingAllocations=!0,this.projectService.getAllocations().subscribe({next:e=>{this.allocations=e.filter(c=>c.projectId===o),this.updateEmployeeLists(),this.loadingAllocations=!1},error:()=>{this.loadingAllocations=!1,this.snackBar.open("Failed to load allocations","Close",{duration:3e3})}})}updateEmployeeLists(){let o=this.allocations.filter(e=>e.status).map(e=>e.empId);this.assignedEmployees=this.allEmployees.filter(e=>o.includes(e.employeeId)),this.availableEmployees=this.allEmployees.filter(e=>!o.includes(e.employeeId)),this.filteredAvailableEmployees=[...this.availableEmployees],this.selectedEmployees=[]}toggleSelect(o){let e=this.selectedEmployees.findIndex(c=>c.employeeId===o.employeeId);e>=0?this.selectedEmployees.splice(e,1):this.selectedEmployees.push(o)}isSelected(o){return this.selectedEmployees.some(e=>e.employeeId===o.employeeId)}assignSelected(){if(!this.selectedProject||this.selectedEmployees.length===0)return;this.assigning=!0;let o=0,e=this.selectedEmployees.length;this.selectedEmployees.forEach(c=>{this.projectService.allocateEmployee({empId:c.employeeId,projectId:this.selectedProject.projectId,createdBy:"Admin",status:!0}).subscribe({next:()=>{o++,o===e&&(this.assigning=!1,this.snackBar.open(`${e} employee(s) assigned successfully`,"Close",{duration:3e3}),this.loadAllocationsForProject(this.selectedProject.projectId))},error:()=>{o++,o===e&&(this.assigning=!1,this.snackBar.open("Some assignments failed","Close",{duration:3e3}),this.loadAllocationsForProject(this.selectedProject.projectId))}})})}removeAllocation(o){if(!this.selectedProject)return;let e=this.allocations.find(c=>c.empId===o.employeeId&&c.projectId===this.selectedProject.projectId);e&&confirm(`Remove ${o.firstName} ${o.lastName} from ${this.selectedProject.projectName}?`)&&this.projectService.removeAllocation(e.allocationId).subscribe({next:()=>{this.snackBar.open("Employee removed from project","Close",{duration:3e3}),this.loadAllocationsForProject(this.selectedProject.projectId)},error:()=>{this.snackBar.open("Failed to remove allocation","Close",{duration:3e3})}})}goBack(){this.router.navigate(["/projects"])}static \u0275fac=function(e){return new(e||t)};static \u0275cmp=E({type:t,selectors:[["app-project-allocation"]],decls:20,vars:3,consts:[[1,"animate-fade-in"],[1,"page-header"],[1,"btn-icon","mb-2",3,"click"],[1,"page-title"],[1,"page-subtitle"],[1,"card","p-6","mb-6"],["appearance","outline",1,"w-full"],[3,"selectionChange","formControl"],[3,"value"],[1,"card","p-12","text-center",2,"color","#94a3b8"],[1,"grid","gap-6","lg:grid-cols-2"],[2,"color","#94a3b8"],[2,"font-size","56px","width","56px","height","56px","margin-bottom","12px"],[2,"font-size","16px","font-weight","500","color","#64748b"],[2,"font-size","14px","margin-top","4px"],[1,"card","p-6"],[1,"flex","items-center","justify-between","mb-4"],[1,"text-lg","font-semibold","text-surface-900"],[1,"text-sm","text-surface-500"],[1,"flex","justify-center","p-8"],[1,"text-center","p-8","text-surface-400"],[1,"space-y-2","max-h-96","overflow-y-auto"],["diameter","32"],[2,"font-size","40px","width","40px","height","40px"],[1,"mt-2"],[1,"allocation-row"],[1,"emp-avatar"],[1,"emp-info"],[1,"emp-name"],[1,"emp-dept"],["mat-icon-button","","color","warn","matTooltip","Remove from project",3,"click"],[2,"margin-bottom","12px"],["matInput","","placeholder","Type to filter...",3,"formControl"],["matSuffix",""],[1,"space-y-2","max-h-72","overflow-y-auto"],[1,"allocation-row",3,"selected"],[1,"mt-4","pt-4","border-t","border-surface-200"],[1,"allocation-row",3,"click"],[3,"click","change","checked"],["mat-raised-button","","color","primary",3,"click","disabled"],["diameter","20",2,"display","inline-block","margin-right","8px"]],template:function(e,c){e&1&&(i(0,"div",0)(1,"div",1)(2,"button",2),b("click",function(){return c.goBack()}),i(3,"mat-icon"),d(4,"arrow_back"),a()(),i(5,"h1",3),d(6,"Project Allocation"),a(),i(7,"p",4),d(8,"Assign and manage employee allocations across projects"),a()(),i(9,"div",5)(10,"mat-form-field",6)(11,"mat-label"),d(12,"Select Project"),a(),i(13,"mat-select",7),b("selectionChange",function(l){return c.onProjectChange(l.value)}),i(14,"mat-option",8),d(15,"Choose a project"),a(),I(16,Ye,4,3,"mat-option",8,We),a()()(),u(18,et,7,0,"div",9)(19,st,21,4,"div",10),a()),e&2&&(r(13),h("formControl",c.projectControl),r(),h("value",null),r(2),j(c.projects),r(2),x(c.selectedProject?19:18))},dependencies:[oe,he,re,le,me,se,Fe,Te,Pe,Se,Ne,De,Oe,Le,Re,Ce,ye,ge,_e,pe,Ie,Ee,we,$e,R,Be,Ve,ze],styles:[".card[_ngcontent-%COMP%]{background:#fff;border-radius:12px}.allocation-row[_ngcontent-%COMP%]{display:flex;align-items:center;gap:12px;padding:10px 12px;border-radius:8px;background:#f8fafc;cursor:pointer;transition:background .15s}.allocation-row[_ngcontent-%COMP%]:hover{background:#f1f5f9}.allocation-row.selected[_ngcontent-%COMP%]{background:#eef2ff;outline:2px solid #6366f1}.emp-avatar[_ngcontent-%COMP%]{width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,#6366f1,#4f46e5);display:flex;align-items:center;justify-content:center;color:#fff;font-size:12px;font-weight:600;flex-shrink:0}.emp-info[_ngcontent-%COMP%]{flex:1;display:flex;flex-direction:column}.emp-name[_ngcontent-%COMP%]{font-weight:500;color:#1e293b;font-size:14px}.emp-dept[_ngcontent-%COMP%]{font-size:12px;color:#94a3b8}"]})};export{Ue as ProjectAllocationComponent};
