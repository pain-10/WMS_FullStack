var e=["WFO","WFH","Hybrid"];export{e as a};
