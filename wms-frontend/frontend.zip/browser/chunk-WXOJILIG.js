var a="https://wms-api-mrunal-e8awhsawexaeh2gx.eastasia-01.azurewebsites.net";export{a};
